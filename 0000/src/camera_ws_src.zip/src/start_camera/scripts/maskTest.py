import cv2
import numpy as np
import math
from ultralytics import YOLO
import os
os.environ["KMP_DUPLICATE_LIB_OK"]="TRUE"

def get_smaller_box(box):
    new_box = [0,0,0,0]
    y1 = box[1]
    y2 = box[3]
    x1 = box[0]
    x2 = box[2]

    y_avg = (y1+y2)/2
    x_avg = (x1+x2)/2

    x1 = (x1+x_avg)/2
    x2 = (x2+x_avg)/2

    y1 = (y1+y_avg)/2
    y2 = (y2+y_avg)/2

    new_box[1] = y1
    new_box[3] = y2
    new_box[0] = x1
    new_box[2] = x2

    return new_box

def get_bigger_box(box):
    new_box = [0,0,0,0]
    y1 = box[1]
    y2 = box[3]
    x1 = box[0]
    x2 = box[2]

    new_box[1] = y1-10
    new_box[3] = y2+10
    new_box[0] = x1-10
    new_box[2] = x2+10

    return new_box

def get_background_box(box):
    background_box = [0,0,0,0]
    y1 = box[1]
    y2 = box[3]
    x1 = box[0]
    x2 = box[2]

    y_size = y2-y1
    x_size = x2-x1

    y_size = .1*y_size
    x_size = .1*x_size

    y2 = y1+y_size
    x1 = x2-x_size

    background_box = [x1,y1,x2,y2]
    return background_box

def read_colors(image, box):
    #convert image to HSV and saturate
    #hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    saturation_factor = 3
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1] * saturation_factor, 0, 255)

    #get sampling region box and background color box
    sampling_region_box = get_smaller_box(box)
    bigger_detection_box = get_bigger_box(box)
    background_box = get_background_box(box)

    #sample colors from within detection
    sampling_region = np.zeros_like(hsv_image)  #black out everything outside of sampling region
    sampling_region[int(sampling_region_box[1]):int(sampling_region_box[3]), int(sampling_region_box[0]):int(sampling_region_box[2])] = hsv_image[int(sampling_region_box[1]):int(sampling_region_box[3]), int(sampling_region_box[0]):int(sampling_region_box[2])]
    cv2.imshow("sampling region", sampling_region)

    #create a bigger bounding box
    detection_region = np.zeros_like(hsv_image)
    detection_region[int(bigger_detection_box[1]):int(bigger_detection_box[3]), int(bigger_detection_box[0]):int(bigger_detection_box[2])] = hsv_image[int(bigger_detection_box[1]):int(bigger_detection_box[3]), int(bigger_detection_box[0]):int(bigger_detection_box[2])]

    #define background region and region of interest
    back = hsv_image[int(background_box[1]):int(background_box[3]), int(background_box[0]):int(background_box[2])]

    #get all values of HSV within sampling region
    hue_values = sampling_region[:, :, 0]
    saturation_values = sampling_region[:, :, 1]
    value_values = sampling_region[:, :, 2]


    #Calculate the min and max HSV values in the sampling region
    hue_min, hue_max = np.min(hue_values), np.max(hue_values)
    sat_min, sat_max = np.min(saturation_values), np.max(saturation_values)
    val_min, val_max = np.min(value_values), np.max(value_values)

    #create lower and upper bound for mask
    lower_bound = np.array([hue_min, sat_min, val_min])
    upper_bound = np.array([hue_max, sat_max, val_max])

    # Apply the mask
    mask = cv2.inRange(hsv_image, lower_bound, upper_bound)

    # Step 7: Use the mask to segment the water droplet
    segmented_image = cv2.bitwise_and(image, detection_region, mask=mask)
    #segmented_image = cv2.bitwise_and(image, detection_region, mask=negative_mask)

    mask = segmented_image

    # Step 1: Convert to grayscale if it's not already grayscale
    if len(mask.shape) == 3:  # If the image has 3 channels (e.g., color)
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)

    mask = cv2.GaussianBlur(mask, (5,5), 0)
    mask = cv2.erode(mask, (5,5),iterations = 1)
    mask = cv2.dilate(mask, (5,5),iterations = 1)


    # Step 2: Threshold the image to get a binary mask
    # This will turn the grayscale image into a binary mask (0 for background, 255 for the object)
    #_, mask = cv2.threshold(mask, 127, 255, cv2.THRESH_BINARY)

    # Step 3: Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Now you can proceed with further processing, like finding the contact angle
    # Example: Let's draw the contours on the image for visualization
    result_image = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)  # Convert mask to color for visualization
    cv2.drawContours(result_image, contours, -1, (0, 255, 0), 3)  # Draw contours in green



    pts = np.array(contours[0], np.int32).reshape((-1, 2))

    cv2.polylines(result_image, [pts], isClosed=False, color=(0, 255, 0), thickness=1)

    #filtered_points = pts[(pts[:, 0] < np.min(pts[:, 0]) + 50) & (pts[:, 1] > np.min(pts[:, 1]) + 10) & (pts[:, 1] < np.max(pts[:, 1]) - 10)]
    # Convert the first contour to an array of points
    pts = np.array(contours[0], np.int32).reshape((-1, 2))

    # Create a copy of the result image to avoid overwriting
    result_image_copy = result_image.copy()

    # --- LEFT SIDE PROCESSING ---
    # Filter points to focus on the left side (near the minimum x-coordinate)
    left_filtered_points = pts[(pts[:, 0] < np.min(pts[:, 0]) + 50) & 
                            (pts[:, 1] > np.min(pts[:, 1]) + 10) & 
                            (pts[:, 1] < np.max(pts[:, 1]) - 10)]

    # If there are any filtered points left, fit a polynomial for the left side
    if len(left_filtered_points) > 0:
        left_poly_coeff = np.polyfit(left_filtered_points[:, 0], left_filtered_points[:, 1], 2)
        left_poly_eq = np.poly1d(left_poly_coeff)

        # Plot the left polynomial curve
        left_x_vals = np.linspace(np.min(left_filtered_points[:, 0]), np.max(left_filtered_points[:, 0]), 100)
        left_y_vals = left_poly_eq(left_x_vals)
        for x, y in zip(left_x_vals.astype(int), left_y_vals.astype(int)):
            cv2.circle(result_image_copy, (x, y), 1, (255, 0, 0), -1)  # Red dots for the polynomial curve

        # Calculate tangent at the leftmost point
        left_x_tangent = int(np.min(left_filtered_points[:, 0]))
        left_y_tangent = int(left_poly_eq(left_x_tangent))
        left_tangent_slope = np.polyder(left_poly_eq)(left_x_tangent)
        left_angle_rad = np.arctan(left_tangent_slope)
        left_angle_deg = -(np.degrees(left_angle_rad))

        # Draw the left tangent line and the contact angle
        cv2.line(result_image_copy, (left_x_tangent, left_y_tangent), 
                (left_x_tangent + 100, int(left_y_tangent + 100 * left_tangent_slope)), 
                (0, 255, 255), 2)
        cv2.putText(result_image_copy, f"{left_angle_deg:.2f} degrees", 
                    (left_x_tangent + 10, left_y_tangent - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)


    # --- RIGHT SIDE PROCESSING ---
    # Filter points to focus on the right side (near the maximum x-coordinate)
    right_filtered_points = pts[(pts[:, 0] > np.max(pts[:, 0]) - 50) & 
                                (pts[:, 1] > np.min(pts[:, 1]) + 10) & 
                                (pts[:, 1] < np.max(pts[:, 1]) - 10)]

    # If there are any filtered points left, fit a polynomial for the right side
    if len(right_filtered_points) > 0:
        right_poly_coeff = np.polyfit(right_filtered_points[:, 0], right_filtered_points[:, 1], 2)
        right_poly_eq = np.poly1d(right_poly_coeff)

        # Plot the right polynomial curve
        right_x_vals = np.linspace(np.min(right_filtered_points[:, 0]), np.max(right_filtered_points[:, 0]), 100)
        right_y_vals = right_poly_eq(right_x_vals)
        for x, y in zip(right_x_vals.astype(int), right_y_vals.astype(int)):
            cv2.circle(result_image_copy, (x, y), 1, (255, 0, 0), -1)  # Red dots for the polynomial curve

        # Calculate tangent at the rightmost point
        right_x_tangent = int(np.max(right_filtered_points[:, 0]))
        right_y_tangent = int(right_poly_eq(right_x_tangent))
        right_tangent_slope = np.polyder(right_poly_eq)(right_x_tangent)

        # Invert the tangent slope to make the line go upwards (for right side)
        right_tangent_slope = -right_tangent_slope  # Flip the slope direction

        right_angle_rad = np.arctan(right_tangent_slope)
        right_angle_deg = -(np.degrees(right_angle_rad))

        # Draw the right tangent line and the contact angle
        cv2.line(result_image_copy, (right_x_tangent, right_y_tangent), 
         (right_x_tangent - 100, int(right_y_tangent + 100 * right_tangent_slope)),  # Moving right and upward
         (0, 255, 255), 2)
        cv2.putText(result_image_copy, f"{right_angle_deg:.2f} degrees", 
                    (right_x_tangent + 10, right_y_tangent - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

    # Show the final result with both sides processed
    cv2.imshow('Droplet Contact Angles', result_image_copy)

       
model = YOLO('yolov8m-seg-custom.pt')

# Open the video file
#video_path = 0	#use webcam
video_path = 'drop003.mp4'	#use video
cap = cv2.VideoCapture(video_path)

# Loop through the video frames

while cap.isOpened():
    # Read a frame from the video
    success, frame = cap.read()

    if success:
        # Run YOLOv8 inference on the frame
        results = model.predict(source=frame,retina_masks=True, verbose=False)
        # Visualize the results on the frame
        #annotated_frame = results[0].plot()
        # Get the box detection tensor
        if len(results[0].boxes.cls) > 0:
            #cv2.imshow("YOLOv8 Inference", annotated_frame)
            box = results[0].boxes.xyxy.tolist()
            print(box[0])
            read_colors(frame, box[0])
            #refine_mask(frame, box[0])


        if cv2.waitKey(2) & 0xFF == ord("q"):
            break

    else:
        break
cv2.destroyAllWindows()
