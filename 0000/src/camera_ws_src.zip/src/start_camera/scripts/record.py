import cv2
import numpy as np
import rospy
from std_msgs.msg import Empty
from ultralytics import YOLO

def callback(data):
    cap = cv2.VideoCapture(0)   #detect on webcam
    filename = "recording.avi"
    # Check if the webcam is opened correctly
    if not cap.isOpened():
        rospy.loginfo("Error: Could not open webcam.")
        exit()
    else:
        rospy.loginfo("camera started")

    # Get the frame width and height from the webcam
    frame_width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    frame_height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    # Set up the VideoWriter object to save the video (output file, codec, frame rate, and frame size)
    fourcc = cv2.VideoWriter_fourcc(*'XVID')  # You can also use other codecs like 'MJPG' or 'MP4V'
    out = cv2.VideoWriter(filename, fourcc, 20.0, (frame_width, frame_height))

    while True:
        ret, frame = cap.read()  # Capture frame-by-frame
        
        if not ret:
            rospy.loginfo("Failed to grab frame.")
            break
        
        # Write the frame to the output video file
        out.write(frame)
        
        # Display the frame (for live preview)
        cv2.imshow('Webcam', frame)
        
        # Exit the loop if the 'q' key is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    # Release everything when done
    cap.release()
    out.release()
    cv2.destroyAllWindows()
    rospy.loginfo(f"Recording ended, results saved to {filename}")


def wait_for_start():
    rospy.init_node('trigger_camera', anonymous=True)

    rospy.Subscriber("/drop", Empty, callback)
    
    rospy.loginfo("Ready for start...")
    rospy.spin()



if __name__ == '__main__':
    try:
        wait_for_start()
    except rospy.ROSInterruptException:
        pass
