#!/usr/bin/env python
import rospy
from std_msgs.msg import Empty

def start():
    pub = rospy.Publisher('start_publisher', Empty, queue_size=5)
    rospy.init_node('talker', anonymous=True)
    
    pub.publish()

if __name__ == '__main__':
    try:
        start()
    except rospy.ROSInterruptException:
        pass