#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import math
import time
from ultralytics import YOLO
from std_msgs.msg import Empty

#some global variables to know when to display results
time_of_last_detection = 10
print_contact = False
avg_contact_angle = 0
angle_count = 0

#variables for file
timestamp_csv = ["Time (s)"]
detection_classification_csv = ["Class"]
boundingBox_csv = ["Bounding Box (xyxy)"]
contactAngle_csv = ["Contact Angle (deg)"]

#get a smaller bounding box, used for color sampling area for mask
def get_smaller_box(box):
    new_box = [0,0,0,0]
    y1 = box[1]
    y2 = box[3]
    x1 = box[0]
    x2 = box[2]

    y_avg = (y1+y2)/2
    x_avg = (x1+x2)/2

    x1 = (x1+x_avg)/2
    x2 = (x2+x_avg)/2

    y1 = (y1+y_avg)/2
    y2 = (y2+y_avg)/2

    new_box[1] = y1
    new_box[3] = y2
    new_box[0] = x1
    new_box[2] = x2

    return new_box

#get a bigger bounding box, used to mask out the background
def get_bigger_box(box):
    new_box = [0,0,0,0]
    y1 = box[1]
    y2 = box[3]
    x1 = box[0]
    x2 = box[2]

    new_box[1] = y1-10
    new_box[3] = y2+10
    new_box[0] = x1-10
    new_box[2] = x2+10

    return new_box

#write results to csv file
def writeToCSV():
    global timestamp_csv
    global detection_classification_csv
    global boundingBox_csv
    global contactAngle_csv
    np.savetxt('Detections.csv', [p for p in zip(timestamp_csv, detection_classification_csv, boundingBox_csv, contactAngle_csv)], delimiter=',', fmt='%s')

#draw bounding box on frame, calculate time of detections
def drawBoundingBox(results, detection_count, start_time, elapsed_time, name_of_prev_object):
    # Visualize the results on the frame
    annotated_frame = results[0].plot()
    #variables used for output
    global time_of_last_detection 
    global print_contact
    global timestamp_csv
    global detection_classification_csv
    global boundingBox_csv
    # Get the box detection tensor
    if len(results[0].boxes.cls) > 0:
        name_of_object_detected = results[0].verbose()      #name of detected objects
        current_time = time.time() - start_time             #track elapsed time from start
        box = results[0].boxes.xyxy.tolist()
        box = box[0]
        time_of_prev_detection = current_time - elapsed_time[0]
        #check if first object is detected -->  print first detection --> save time of first detection, print message, push file, save frame, make it new elapsed time
        #check if previous object is the same as current object --> print total time of detection, push to fil
        if(detection_count[0] == 0):                   #first detection
            elapsed_time[0] = time.time() - start_time
            elapsed_time[1] = time.time() - start_time

            message = f"---First detection at {elapsed_time[0]: .4f} seconds---"

            cv2.imshow("YOLOv8 Inference", annotated_frame)

            detection_count[0] = detection_count[0] + 1
            name_of_prev_object = name_of_object_detected
        
        elif(name_of_object_detected != name_of_prev_object):
            elapsed_time[1] = current_time - elapsed_time[1]
            message = f"--Detected {name_of_prev_object} for a total of {elapsed_time[1]: .4f} seconds--"
            #ros.loginfo(message)
            rospy.loginfo(message)

            cv2.imshow("YOLOv8 Inference", annotated_frame)
            if(detection_count[0] < 3):
                detection_count[0] = detection_count[0] + 1

            name_of_prev_object = name_of_object_detected

        else:
            elapsed_time[0] = time.time() - start_time
            message = f"Detected {name_of_object_detected} at time {elapsed_time[0]: .4f} seconds"

            cv2.imshow("YOLOv8 Inference", annotated_frame)
            if(detection_count[0] < 3):
                detection_count[0] = detection_count[0] + 1

            name_of_prev_object = name_of_object_detected
        
        time_of_last_detection = time_of_prev_detection + time_of_last_detection
        if time_of_last_detection > .25:
            rospy.loginfo(message)
            timestamp_csv.append(f"{current_time:.2f}")
            detection_classification_csv.append(name_of_object_detected.replace(",", ""))
            boundingBox_csv.append(f"{box[0]}  {box[1]}  {box[2]}  {box[3]}")
            time_of_last_detection = 0
            print_contact = True
    
    return name_of_prev_object

#calculate left and right contact angles based on color mask of droplet
def calculateContactAngle(image, box):
    #convert image to HSV and saturate
    saturation_factor = 3
    hsv_image = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
    hsv_image[:, :, 1] = np.clip(hsv_image[:, :, 1] * saturation_factor, 0, 255)

    #get sampling region box and background color box
    sampling_region_box = get_smaller_box(box)
    bigger_detection_box = get_bigger_box(box)

    #sample colors from within detection
    sampling_region = np.zeros_like(hsv_image)  #black out everything outside of sampling region
    sampling_region[int(sampling_region_box[1]):int(sampling_region_box[3]), int(sampling_region_box[0]):int(sampling_region_box[2])] = hsv_image[int(sampling_region_box[1]):int(sampling_region_box[3]), int(sampling_region_box[0]):int(sampling_region_box[2])]

    #create a bigger bounding box to mask out background
    detection_region = np.zeros_like(hsv_image)
    detection_region[int(bigger_detection_box[1]):int(bigger_detection_box[3]), int(bigger_detection_box[0]):int(bigger_detection_box[2])] = hsv_image[int(bigger_detection_box[1]):int(bigger_detection_box[3]), int(bigger_detection_box[0]):int(bigger_detection_box[2])]

    #get all values of HSV within sampling region
    hue_values = sampling_region[:, :, 0]
    saturation_values = sampling_region[:, :, 1]
    value_values = sampling_region[:, :, 2]

    #Calculate the min and max HSV values in the sampling region
    hue_min, hue_max = np.min(hue_values), np.max(hue_values)
    sat_min, sat_max = np.min(saturation_values), np.max(saturation_values)
    val_min, val_max = np.min(value_values), np.max(value_values)

    #create lower and upper bound for mask
    lower_bound = np.array([hue_min, sat_min, val_min])
    upper_bound = np.array([hue_max, sat_max, val_max])

    # Apply the mask
    mask = cv2.inRange(hsv_image, lower_bound, upper_bound)

    # Use the mask to segment the water droplet
    segmented_image = cv2.bitwise_and(image, detection_region, mask=mask)
    mask = segmented_image

    # Convert to grayscale
    if len(mask.shape) == 3:  # If the image has 3 channels (e.g., color)
        mask = cv2.cvtColor(mask, cv2.COLOR_BGR2GRAY)

    # apply smoothing to mask
    mask = cv2.GaussianBlur(mask, (5,5), 0)
    mask = cv2.erode(mask, (5,5),iterations = 1)
    mask = cv2.dilate(mask, (5,5),iterations = 1)

    # Find contours
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Draw contours on image
    result_image = cv2.cvtColor(mask, cv2.COLOR_GRAY2BGR)  # Convert mask to color for visualization
    cv2.drawContours(result_image, contours, -1, (0, 255, 0), 3)  # Draw contours in green

    # Calculate Contact Angles
    pts = np.array(contours[0], np.int32).reshape((-1, 2))
    cv2.polylines(result_image, [pts], isClosed=False, color=(0, 255, 0), thickness=1)
    pts = np.array(contours[0], np.int32).reshape((-1, 2))

    # Create a copy of the result image to avoid overwriting
    result_image_copy = result_image.copy()

    # --- LEFT SIDE PROCESSING ---
    # Filter points to focus on the left side (near the minimum x-coordinate)
    left_filtered_points = pts[(pts[:, 0] < np.min(pts[:, 0]) + 50) & 
                            (pts[:, 1] > np.min(pts[:, 1]) + 10) & 
                            (pts[:, 1] < np.max(pts[:, 1]) - 10)]

    # If there are any filtered points left, fit a polynomial for the left side
    if len(left_filtered_points) > 0:
        left_poly_coeff = np.polyfit(left_filtered_points[:, 0], left_filtered_points[:, 1], 2)
        left_poly_eq = np.poly1d(left_poly_coeff)

        # Plot the left polynomial curve
        left_x_vals = np.linspace(np.min(left_filtered_points[:, 0]), np.max(left_filtered_points[:, 0]), 100)
        left_y_vals = left_poly_eq(left_x_vals)
        for x, y in zip(left_x_vals.astype(int), left_y_vals.astype(int)):
            cv2.circle(result_image_copy, (x, y), 1, (255, 0, 0), -1)  # Red dots for the polynomial curve

        # Calculate tangent at the leftmost point
        left_x_tangent = int(np.min(left_filtered_points[:, 0]))
        left_y_tangent = int(left_poly_eq(left_x_tangent))
        left_tangent_slope = np.polyder(left_poly_eq)(left_x_tangent)
        left_angle_rad = np.arctan(left_tangent_slope)
        left_angle_deg = -(np.degrees(left_angle_rad))


        # Draw the left tangent line and the contact angle
        cv2.line(result_image_copy, (left_x_tangent, left_y_tangent), 
                (left_x_tangent + 100, int(left_y_tangent + 100 * left_tangent_slope)), 
                (0, 255, 255), 2)
        cv2.putText(result_image_copy, f"{left_angle_deg:.2f} degrees", 
                    (left_x_tangent + 10, left_y_tangent - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

    global avg_contact_angle
    global angle_count
    global print_contact
    # --- RIGHT SIDE PROCESSING ---
    # Filter points to focus on the right side (near the maximum x-coordinate)
    right_filtered_points = pts[(pts[:, 0] > np.max(pts[:, 0]) - 50) & 
                                (pts[:, 1] > np.min(pts[:, 1]) + 10) & 
                                (pts[:, 1] < np.max(pts[:, 1]) - 10)]

    # If there are any filtered points left, fit a polynomial for the right side
    if len(right_filtered_points) > 0:
        right_poly_coeff = np.polyfit(right_filtered_points[:, 0], right_filtered_points[:, 1], 2)
        right_poly_eq = np.poly1d(right_poly_coeff)

        # Plot the right polynomial curve
        right_x_vals = np.linspace(np.min(right_filtered_points[:, 0]), np.max(right_filtered_points[:, 0]), 100)
        right_y_vals = right_poly_eq(right_x_vals)
        for x, y in zip(right_x_vals.astype(int), right_y_vals.astype(int)):
            cv2.circle(result_image_copy, (x, y), 1, (255, 0, 0), -1)  # Red dots for the polynomial curve

        # Calculate tangent at the rightmost point
        right_x_tangent = int(np.max(right_filtered_points[:, 0]))
        right_y_tangent = int(right_poly_eq(right_x_tangent))
        right_tangent_slope = np.polyder(right_poly_eq)(right_x_tangent)

        # Invert the tangent slope to make the line go upwards (for right side)
        right_tangent_slope = -right_tangent_slope  # Flip the slope direction

        right_angle_rad = np.arctan(right_tangent_slope)
        right_angle_deg = -(np.degrees(right_angle_rad))

        if(right_angle_deg > 0):
                avg_contact_angle += right_angle_deg
                angle_count += 1

                message = f"Contact angle: {right_angle_deg} degrees"
                if print_contact:
                    avg_contact_angle /= angle_count
                    print(message)
                    contactAngle_csv.append(f"{avg_contact_angle:.2f}")
                    avg_contact_angle = 0
                    angle_count = 0
                    print_contact = False
        else:
            if print_contact:
                contactAngle_csv.append("")

        # Draw the right tangent line and the contact angle
        cv2.line(result_image_copy, (right_x_tangent, right_y_tangent), 
         (right_x_tangent - 100, int(right_y_tangent + 100 * right_tangent_slope)),  # Moving right and upward
         (0, 255, 255), 2)
        cv2.putText(result_image_copy, f"{right_angle_deg:.2f} degrees", 
                    (right_x_tangent + 10, right_y_tangent - 10), 
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)


    # Show the final result with both sides processed
    cv2.imshow('Droplet Contact Angles', result_image_copy)

def callback(data):
    cap = cv2.VideoCapture("/home/nvidia/Desktop/yolo/drop003.mp4") #detect on video 
    #cap = cv2.VideoCapture(0)   #detect on webcam
    rospy.loginfo("camera started")
    model = YOLO("/home/nvidia/Desktop/yolo/yolov8m-seg-custom.engine")
    rospy.loginfo("detection started")
    detection_count = [0]
    elapsed_time = [0.0,0.0]
    start_time = time.time()
    name_of_prev_object = ""

    # Perform detection
    #results = model.predict(source=0, show=True, retina_masks=True)
    while cap.isOpened():
        success, frame = cap.read()
        results = model.predict(source=frame, retina_masks=True, verbose=True)
        if success:
            if len(results[0].boxes.cls) > 0:
                box = results[0].boxes.xyxy.tolist()
                name_of_prev_object = drawBoundingBox(results, detection_count, start_time, elapsed_time, name_of_prev_object)
                calculateContactAngle(frame, box[0])
            if "Fully Drowned" in name_of_prev_object:
                rospy.loginfo("Droplet fully drowned")
                break
            if cv2.waitKey(2) & 0xFF == ord("q"):
                break

    writeToCSV()
    cap.release()
    cv2.destroyAllWindows()
    
    rospy.loginfo("outputs written to Detections.csv")
    rospy.loginfo("detection ended")



def wait_for_start():
    rospy.init_node('trigger_camera', anonymous=True)

    rospy.Subscriber("/drop", Empty, callback)
    #rospy.Subscriber("start_publisher", Empty, callback)
    
    rospy.loginfo("Ready for start...")
    rospy.spin()


if __name__ == '__main__':
    try:
        wait_for_start()
    except rospy.ROSInterruptException:
        pass
