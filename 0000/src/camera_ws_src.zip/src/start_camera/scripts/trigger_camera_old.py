#!/usr/bin/env python
import rospy
import cv2
import numpy as np
import time
from ultralytics import YOLO
from std_msgs.msg import Empty

def drawBoundingBox(results, detection_count, start_time, elapsed_time, name_of_prev_object):
    # Visualize the results on the frame
    annotated_frame = results[0].plot()
    
    # Get the box detection tensor
    if len(results[0].boxes.cls) > 0:
        name_of_object_detected = results[0].verbose()      #name of detected objects
        current_time = time.time() - start_time             #track elapsed time from start
        #check if first object is detected -->  print first detection --> save time of first detection, print message, push file, save frame, make it new elapsed time
        #check if previous object is the same as current object --> print total time of detection, push to fil
        if(detection_count[0] == 0):                   #first detection
            elapsed_time[0] = time.time() - start_time

            message = f"---First detection at {elapsed_time[0]: .4f} seconds---"
            print(message)

            cv2.imshow("YOLOv8 Inference", annotated_frame)

            detection_count[0] = detection_count[0] + 1
            name_of_prev_object = name_of_object_detected
        
        elif(name_of_object_detected != name_of_prev_object):
            elapsed_time[0] = current_time - elapsed_time[0]
            message = f"--Detected {name_of_prev_object} for a total of {elapsed_time[0]: .4f} seconds--"
            print(message)

            cv2.imshow("YOLOv8 Inference", annotated_frame)
            if(detection_count[0] < 3):
                detection_count[0] = detection_count[0] + 1

            name_of_prev_object = name_of_object_detected

        else:
            elapsed_time[0] = time.time() - start_time
            message = f"Detected {name_of_object_detected} at time {elapsed_time[0]: .4f} seconds"
            print(message)

            cv2.imshow("YOLOv8 Inference", annotated_frame)
            if(detection_count[0] < 3):
                detection_count[0] = detection_count[0] + 1

            name_of_prev_object = name_of_object_detected
    
    return name_of_prev_object



def calculateContactAngle(results, frame):
    if results[0].masks and results[0].masks.xy:  # Check if masks exist and have data
        original_img = frame.copy()
        surface_pixels = results[0].masks.xy[0]
        pts = np.array(surface_pixels, np.int32).reshape((-1, 2))

        cv2.polylines(original_img, [pts], isClosed=False, color=(0, 255, 0), thickness=1)

        filtered_points = pts[(pts[:, 0] < np.min(pts[:, 0]) + 50) & (pts[:, 1] > np.min(pts[:, 1]) + 10) & (pts[:, 1] < np.max(pts[:, 1]) - 10)]

        if len(filtered_points) > 0:
            poly_coeff = np.polyfit(filtered_points[:, 0], filtered_points[:, 1], 2)
            poly_eq = np.poly1d(poly_coeff)

            x_vals = np.linspace(np.min(filtered_points[:, 0]), np.max(filtered_points[:, 0]), 100)
            y_vals = poly_eq(x_vals)
            for x, y in zip(x_vals.astype(int), y_vals.astype(int)):
                cv2.circle(original_img, (x, y), 1, (255, 0, 0), -1)  # Red dots for the polynomial curve

            x_tangent = int(np.min(filtered_points[:, 0]))
            y_tangent = int(poly_eq(x_tangent))
            tangent_slope = np.polyder(poly_eq)(x_tangent)
            angle_rad = np.arctan(tangent_slope)
            angle_deg = -(np.degrees(angle_rad))

            cv2.line(original_img, (x_tangent, y_tangent), (x_tangent + 100, int(y_tangent + 100 * tangent_slope)), (0, 255, 255), 2)
            cv2.putText(original_img, f"{angle_deg:.2f} degrees", (x_tangent + 10, y_tangent - 10), cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 255, 255), 2)

            message = f"Contact angle: {angle_deg} degrees"
            print(message)
            cv2.imshow('Droplet Contact Angle', original_img) 
        #if (detection_count < 3):
        #    filename = f"Detection_Frames/DropAngle{detection_count}.jpg"
        #    cv2.imwrite(filename, original_img)

    else:
        print("No mask data available for processing or no detections.")

def callback(data):
    #cap = cv2.VideoCapture("/home/nvidia/Desktop/yolo/drop003.mp4") #detect on video 
    cap = cv2.VideoCapture(0)   #detect on webcam
    rospy.loginfo("camera started")
    model = YOLO("/home/nvidia/Desktop/yolo/yolov8m-seg-custom.engine")
    detection_count = [0]
    elapsed_time = [0.0]
    start_time = time.time()
    name_of_prev_object = ""

    # Perform detection
    #results = model.predict(source=0, show=True, retina_masks=True)
    while cap.isOpened():
        success, frame = cap.read()
        results = model.predict(source=frame, retina_masks=True)
        if success:
            name_of_prev_object = drawBoundingBox(results, detection_count, start_time, elapsed_time, name_of_prev_object)
            calculateContactAngle(results, frame)
            if name_of_prev_object == "1 Fully Drowned":
                break
            if cv2.waitKey(2) & 0xFF == ord("q"):
                break


    cap.release()
    cv2.destroyAllWindows()
    
    rospy.loginfo("detection ended")



def wait_for_start():
    rospy.init_node('trigger_camera', anonymous=True)

    rospy.Subscriber("drop", Empty, callback)
    
    rospy.loginfo("Ready for start...")
    rospy.spin()



if __name__ == '__main__':
    try:
        wait_for_start()
    except rospy.ROSInterruptException:
        pass