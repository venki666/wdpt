#include <ros/ros.h>
#include <mavros_msgs/RCIn.h>

#include <gpiod.hpp>
#include <unistd.h>

class Dropper {
    ros::NodeHandle nh_;
    ros::Subscriber sub;

    int prev_val; // previous value of transmitter channel

    gpiod::chip chip;
    gpiod::line dropper_pin;

    void activateDrop() {
        dropper_pin.set_value(1);
        usleep(10000);
        dropper_pin.set_value(0);
        ROS_INFO("Drop activated");
    }

    void transmitterCallback(const mavros_msgs::RCIn::ConstPtr &msg) {
        int dropper_channel = msg->channels.at(9);
        if (dropper_channel > 1878 && prev_val < 1110) activateDrop();
        prev_val = dropper_channel;
    }

public:
    Dropper(ros::NodeHandle *nh)
    :nh_(*nh) {
        // set up gpio
        chip = gpiod::chip("pinctrl-bcm2711");
        dropper_pin = chip.get_line(16);
        dropper_pin.request({"dropper", gpiod::line_request::DIRECTION_OUTPUT, 0}, 0);

        // set up subscriber
        sub = nh_.subscribe("/mavros/rc/in", 1, &Dropper::transmitterCallback, this);
    }
};





int main(int argc, char* argv[]) {
    ros::init(argc, argv, "dropper");
    ros::NodeHandle nh;

    Dropper myDropper(&nh);

    ros::spin();

    return 0;
}
