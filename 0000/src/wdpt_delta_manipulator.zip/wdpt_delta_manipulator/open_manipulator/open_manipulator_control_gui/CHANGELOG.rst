^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package open_manipulator_control_gui
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

2.0.1 (2019-02-18)
------------------
* added dependency option for open_manipulator_control_gui package
* Contributors: Pyo

2.0.0 (2019-02-08)
------------------
* updated the CHANGELOG and version to release binary packages (first relese)
* updated function name, UI
* added group names and gripper args
* added position only client
* modified topic names, end-effector name
* Contributors: Darby Lim, Hye-Jong KIM, Yong-Ho Na, Guilherme de Campos Affonso, Pyo
